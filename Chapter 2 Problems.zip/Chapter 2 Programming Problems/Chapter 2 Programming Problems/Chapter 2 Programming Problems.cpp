// Chapter 2 Programming Problems.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;
// Problem 1: Schedule
// Print out your weekly schedule.
void main1() {
 string Day = "Monday";
 string Time = " 11:00 AM";
 string Class1 = " Dance 101";
 cout << Day << Time << Class1 << endl << endl;
}
// Problem 2: Permutations
// Write out all 6 permutations for these three sentences.
void main2() {
    string Line1 = "I saw the big brown bear.";
    string Line2 = "The big brown bear saw me.";
    string Line3 = "Oh! What a frigtening experience!";
    cout << Line1 << endl << Line2 << endl << Line3 << endl << endl << Line1 << endl << Line3 << endl << Line2 << endl << endl << Line2 << endl << Line3 << endl << Line1 << endl << endl << Line2 << endl << Line1 << endl << Line3 << endl << endl << Line3 << endl << Line2 << endl << Line1 << endl << endl << Line3 << endl << Line1 << endl << Line2 << endl << endl;
}
// Problem 3: Checkerboard
// Create a checkerboard pattern using stars and empty spaces.
void main3() {
    string Spaces = " * * * *";
    string Stars = "* * * * ";
    cout << Spaces << endl << Stars << endl << Spaces << endl << Stars << endl << Spaces << endl << Stars << endl << Spaces << endl << Stars << endl << endl;
}
// Problem 4: Business Card
// Print business cards with your name, address, phone number, and email.
// They should be in 2 columns with 4 rows.
void main4() {
    string Name = "Danessa Yip    ";
    string Street = "2137 Arriba Dr ";
    string Phone = "(323)-203-8737 ";
    string Email = "dlyip@uci.edu  ";
    cout << Name << Name << endl << Street << Street << endl << Phone << Phone << endl << Email << Email << endl << endl;
    cout << Name << Name << endl << Street << Street << endl << Phone << Phone << endl << Email << Email << endl << endl;
    cout << Name << Name << endl << Street << Street << endl << Phone << Phone << endl << Email << Email << endl << endl;
    cout << Name << Name << endl << Street << Street << endl << Phone << Phone << endl << Email << Email << endl << endl;
}

int main()
{
    cout << "---------------Problem 1---------------" << endl<<endl;
    main1();
    cout << "---------------Problem 2---------------" << endl<<endl;
    main2();
    cout << "---------------Problem 3---------------" << endl<<endl;
    main3();
    cout << "---------------Problem 4---------------" << endl<<endl;
    main4();
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
