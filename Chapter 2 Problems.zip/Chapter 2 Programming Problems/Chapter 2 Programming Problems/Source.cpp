// Chapter 3 Programming Problems.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#define _USE_MATH_DEFINES // For constants such as PI.
#include <iostream> // File stream.
#include <cmath> // For math equations.
using namespace std;
// Problem 1: Cone
// Compute and Output Volume of a Cone.
void main5() {
    double diameter;
    double height;
    cin >> diameter; // Input the diameter of the base.
    cin >> height; // Input the height of the cone.
    1.0 / 3.0 * M_PI * diameter / 2.0 * diameter / 2.0 * height;
}
// Problem 2: Permutations
// Write out all 6 permutations for these three sentences.
void main6() {
    string Line1 = "I saw the big brown bear.";
    string Line2 = "The big brown bear saw me.";
    string Line3 = "Oh! What a frigtening experience!";
    cout << Line1 << endl << Line2 << endl << Line3 << endl << endl << Line1 << endl << Line3 << endl << Line2 << endl << endl << Line2 << endl << Line3 << endl << Line1 << endl << endl << Line2 << endl << Line1 << endl << Line3 << endl << endl << Line3 << endl << Line2 << endl << Line1 << endl << endl << Line3 << endl << Line1 << endl << Line2 << endl << endl;
}
// Problem 3: Checkerboard
// Create a checkerboard pattern using stars and empty spaces.
void main7() {
    string Spaces = " * * * *";
    string Stars = "* * * * ";
    cout << Spaces << endl << Stars << endl << Spaces << endl << Stars << endl << Spaces << endl << Stars << endl << Spaces << endl << Stars << endl << endl;
}
// Problem 4: Business Card
// Print business cards with your name, address, phone number, and email.
// They should be in 2 columns with 4 rows.
void main8() {
    string Name = "Danessa Yip    ";
    string Street = "2137 Arriba Dr ";
    string Phone = "(323)-203-8737 ";
    string Email = "dlyip@uci.edu  ";
    cout << Name << Name << endl << Street << Street << endl << Phone << Phone << endl << Email << Email << endl << endl;
    cout << Name << Name << endl << Street << Street << endl << Phone << Phone << endl << Email << Email << endl << endl;
    cout << Name << Name << endl << Street << Street << endl << Phone << Phone << endl << Email << Email << endl << endl;
    cout << Name << Name << endl << Street << Street << endl << Phone << Phone << endl << Email << Email << endl << endl;
}

int main()
{
    cout << "---------------Problem 1---------------" << endl << endl;
    main5();
    cout << "---------------Problem 2---------------" << endl << endl;
    main6();
    cout << "---------------Problem 3---------------" << endl << endl;
    main7();
    cout << "---------------Problem 4---------------" << endl << endl;
    main8();
}
