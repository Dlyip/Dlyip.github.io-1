// Chapter 3 Problems.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

// Chapter 3 Programming Problems.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#define _USE_MATH_DEFINES // For constants such as PI.
#include <iostream> // File stream.
#include <cmath> // For math equations.
#include <iomanip> // For manipulating files.
#include <cctype> // For making letters upper or lower case
#include <string> // For making string functions.
using namespace std;
// Problem 1: Cone
// Compute and Output Volume of a Cone.
void main1() {
    double diameter;
    double height;
    cout << "Input diameter: " << endl;
    cin >> diameter; // Input the diameter of the base.
    cout << "Input height: " << endl;
    cin >> height; // Input the height of the cone.
    double volume = 1.0 / 3.0 * M_PI * diameter / 2.0 * diameter / 2.0 * height; // Output the Volume of the cone
    cout << volume << endl;
}
// Problem 2: Standard Deviations
// Recreate the formula for 4 integers.
void main2() {
    int Integer1;
    int Integer2;
    int Integer3;
    int Integer4;
    float mean;
    float stddev; // Standard Deviation
    cout << "Input Integer 1: " << endl;
    cin >> Integer1; // Input the first integer.
    cout << "Input Integer 2: " << endl;
    cin >> Integer2; // Input the height of the second integer.
    cout << "Input Integer 3: " << endl;
    cin >> Integer3; // Input the height of the third integer.
    cout << "Input Integer 4: " << endl;
    cin >> Integer4; // Input the height of the fourth integer.
    mean = (Integer1 + Integer2 + Integer3 + Integer4) / 4.0; // Calculate the mean
    stddev = sqrt((((Integer1 - mean) * (Integer1 - mean)) + ((Integer2 - mean) * (Integer2 - mean)) + ((Integer3 - mean) * (Integer3 - mean)) + ((Integer4 - mean) * (Integer4 - mean))) / (4-1)); // Calculate the standard deviation.
    cout << "The standard deviation is: " << stddev << endl; // Output the standard deviation.
}
// Problem 3: Factorial
// Calculate the factorial of 15, both directly and with Sterling's Formula.
void main3() {
    
    double factfifteen = 15.0 * 14.0 * 13.0 * 12.0 * 11.0 * 10.0 * 9.0 * 8.0 * 7.0 * 6.0 * 5.0 * 4.0 * 3.0 * 2.0 * 1.0; // Calculating factorial of fifteen directly.
    cout << "This is the direct computation " << factfifteen << endl; // Output the factorial of fifteen.
    double factfifteens = exp(-15.0) * pow(15.0, 15.0) * sqrt(2.0 * M_PI * 15.0); // Calculate the factorial of fifteen with Sterling's equation
    cout << "This is Sterling's equation " << factfifteens << endl; // Output the factorial of fifteen with Sterling's equation.
   
}
// Problem 4: Student's Grade
// Write code that allows a student to compute their grade based on the points earned and total amount of points.
void main4() {
    cout << "What is the score earned on the assignment?" << endl;
    float score;
    cin >> score;
    cout << "What is the total amount of points that can be earned?" << endl;
    float total;
    cin >> total;
    float grade;
    grade = (score / total) * 100;
    cout << "This is the rounded grade: " << ceil(grade) << endl;
    cout << "This is the total grade: " << fixed << setw(5) << grade << endl; // Percent grade.
}

// Problem 5: Constructing a String
// From an original string, create a code that reads "I CAN WRITE CODE THAT RUNS."
void main5() {
    string Sentence = "Program testing can be used to show the presence	of bugs, but never to show their absence.";
    char str; // Set a string to hold the character.
    string Code = "i can write code that runs";
    string UpperCase; // Upper case version of code.
    char Ch; // Declare a character variable.
    double Index; // Declare an index variable.
    for (int i = 0; i <= Code.length(); i++) {
        Ch = Code[i];
        Index = Sentence.find(Ch);
        if (Index <= Sentence.length()){
            Ch = Sentence.at(Index);
        }
        Ch = toupper(Ch);
        UpperCase += Ch;
    }
    cout << UpperCase << endl;
}

// Problem 6: Permutations
// Calculate the combination of 18 students in groups of 3.

// Create a function to find the factorial of each number.
double factorial(double n) {
    double factorialcount = 1;
        for (int i = 1; i <= n; ++i) 
    {
        factorialcount *= i;
    }
        return factorialcount;
}
void main6() {
    double Students = 18.0; // Number of Students.
    double Groups = 3.0; // Number of Groups.
    double Permutations = (factorial(Students)) / ((factorial(Groups)) * (factorial(Students - Groups))); // Calculate the number of permutations.
    cout << "This is the number of permutations: " << Permutations << endl; // Here is the output of the permutations formula.
}

//Problem 7: Printing Names
// Print the first, middle, last names of a person as three separate lines.
void main7() {
    string FirstName;
    string MiddleName;
    string LastName;
    cout << "Input Full Name: " << endl;
    cin >> FirstName;
    cin >> MiddleName;
    cin >> LastName;
    cout << "First Name: " << FirstName << endl;
    cout << "Middle Name: " << MiddleName << endl;
    cout << "Last Name: " << LastName << endl;
}

//Problem 8: Length of Names
// Print the length of names for each person.
void main8() {
    string FirstName;
    string MiddleName;
    string LastName;
    cout << "Input Full Name (again): " << endl;
    cin >> FirstName;
    cin >> MiddleName;
    cin >> LastName;
    cout << "This is the length of the first name: " << FirstName.length() << endl;
    cout << "This is the length of the middle name: " << MiddleName.length() << endl;
    cout << "This is the length of the last name: " << LastName.length() << endl;
}

int main()
{
    cout << "---------------Problem 1---------------" << endl << endl;
    main1();
    cout << "---------------Problem 2---------------" << endl << endl;
    main2();
    cout << "---------------Problem 3---------------" << endl << endl;
    main3();
    cout << "---------------Problem 4---------------" << endl << endl;
    main4();
    cout << "---------------Problem 5---------------" << endl << endl;
    main5();
    cout << "---------------Problem 6---------------" << endl << endl;
    main6();
    cout << "---------------Problem 7---------------" << endl << endl;
    main7();
    cout << "---------------Problem 8---------------" << endl << endl;
    main8();
}